/**********************************************************************
  Copyright(c) 2021 Arm Corporation All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Arm Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**********************************************************************/
#include <aarch64_multibinary.h>

DEFINE_INTERFACE_DISPATCHER(_mh_sha1_murmur3_x64_128_update)
{
        unsigned long auxval = getauxval(AT_HWCAP);
        if (auxval & HWCAP_SHA1)
                return PROVIDER_INFO(mh_sha1_murmur3_update_ce);

        if (auxval & HWCAP_ASIMD)
                return PROVIDER_INFO(mh_sha1_murmur3_update_asimd);

        return PROVIDER_BASIC(_mh_sha1_murmur3_x64_128_update);
}

DEFINE_INTERFACE_DISPATCHER(_mh_sha1_murmur3_x64_128_finalize)
{
        unsigned long auxval = getauxval(AT_HWCAP);
        if (auxval & HWCAP_SHA1)
                return PROVIDER_INFO(mh_sha1_murmur3_finalize_ce);

        if (auxval & HWCAP_ASIMD)
                return PROVIDER_INFO(mh_sha1_murmur3_finalize_asimd);

        return PROVIDER_BASIC(_mh_sha1_murmur3_x64_128_finalize);
}
